import Image from "next/image"
import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section className="relative w-full h-[500px] overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0">
        <Image src="/images/hero-venue.jpeg" alt="Event venue" fill className="object-cover" priority />
        {/* Dark overlay */}
        <div className="absolute inset-0 bg-black/40" />
      </div>

      {/* Content */}
      <div className="relative z-10 h-full flex items-center justify-center">
        <div className="flex gap-4">
          <Button className="bg-[#0077F7] hover:bg-[#0066D6] text-white px-10 py-6 text-lg rounded-lg font-medium">
            View Events
          </Button>
          <Button
            variant="outline"
            className="bg-white hover:bg-gray-100 text-[#000000] px-10 py-6 text-lg rounded-lg font-medium border-2"
          >
            About Us
          </Button>
        </div>
      </div>
    </section>
  )
}
