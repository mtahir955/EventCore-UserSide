import { Search, MapPin, Calendar } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export function SearchSection() {
  return (
    <section className="w-full bg-white py-8">
      <div className="max-w-[1200px] mx-auto px-8">
        <div className="flex items-center gap-4 bg-white rounded-xl shadow-lg p-4">
          {/* Search events */}
          <div className="flex-1 flex items-center gap-3 px-4 py-3 border-r border-gray-200">
            <Search className="w-5 h-5 text-gray-400" />
            <Input
              type="text"
              placeholder="Search events"
              className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0 p-0 text-base"
            />
          </div>

          {/* Select Location */}
          <div className="flex-1 flex items-center gap-3 px-4 py-3 border-r border-gray-200">
            <MapPin className="w-5 h-5 text-gray-400" />
            <Input
              type="text"
              placeholder="Select Location"
              className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0 p-0 text-base"
            />
          </div>

          {/* Select Date */}
          <div className="flex-1 flex items-center gap-3 px-4 py-3">
            <Calendar className="w-5 h-5 text-gray-400" />
            <Input
              type="text"
              placeholder="Select Date"
              className="border-0 focus-visible:ring-0 focus-visible:ring-offset-0 p-0 text-base"
            />
          </div>

          {/* Search button */}
          <Button className="bg-[#0077F7] hover:bg-[#0066D6] text-white px-12 py-6 text-base rounded-lg font-medium">
            Search
          </Button>
        </div>
      </div>
    </section>
  )
}
