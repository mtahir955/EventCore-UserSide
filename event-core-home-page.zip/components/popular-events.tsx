import Image from "next/image"
import { MapPin, Calendar, Users, Clock, Plus } from "lucide-react"
import { Card } from "@/components/ui/card"

const events = [
  {
    id: 1,
    image: "/images/elegant-venue.jpeg",
    price: "$99.99",
    host: "Eric Grzybowski",
    title: "Starry Nights Music Fest",
    description:
      "A magical evening under the stars with live bands, food stalls, and an eclectic crowd that will amaze.",
    location: "California",
    date: "13 June 2025",
    audience: "150 Audience",
    time: "08:00 PM - 09:00 PM",
  },
  {
    id: 2,
    image: "/images/concert-crowd.png",
    price: "$99.99",
    host: "Eric Grzybowski",
    title: "Starry Nights Music Fest",
    description:
      "A magical evening under the stars with live bands, food stalls, and an eclectic crowd that will amaze.",
    location: "California",
    date: "13 June 2025",
    audience: "150 Audience",
    time: "08:00 PM - 09:00 PM",
  },
  {
    id: 3,
    image: "/images/speaker-presentation.png",
    price: "$99.99",
    host: "Eric Grzybowski",
    title: "Starry Nights Music Fest",
    description:
      "A magical evening under the stars with live bands, food stalls, and an eclectic crowd that will amaze.",
    location: "California",
    date: "13 June 2025",
    audience: "150 Audience",
    time: "08:00 PM - 09:00 PM",
  },
  {
    id: 4,
    image: "/images/elegant-venue.jpeg",
    price: "$99.99",
    host: "Eric Grzybowski",
    title: "Starry Nights Music Fest",
    description:
      "A magical evening under the stars with live bands, food stalls, and an eclectic crowd that will amaze.",
    location: "California",
    date: "13 June 2025",
    audience: "150 Audience",
    time: "08:00 PM - 09:00 PM",
  },
  {
    id: 5,
    image: "/images/concert-crowd.png",
    price: "$99.99",
    host: "Eric Grzybowski",
    title: "Starry Nights Music Fest",
    description:
      "A magical evening under the stars with live bands, food stalls, and an eclectic crowd that will amaze.",
    location: "California",
    date: "13 June 2025",
    audience: "150 Audience",
    time: "08:00 PM - 09:00 PM",
  },
  {
    id: 6,
    image: "/images/elegant-venue.jpeg",
    price: "$99.99",
    host: "Eric Grzybowski",
    title: "Starry Nights Music Fest",
    description:
      "A magical evening under the stars with live bands, food stalls, and an eclectic crowd that will amaze.",
    location: "California",
    date: "13 June 2025",
    audience: "150 Audience",
    time: "08:00 PM - 09:00 PM",
  },
]

export function PopularEvents() {
  return (
    <section className="w-full bg-white py-16">
      <div className="max-w-[1200px] mx-auto px-8">
        {/* Section header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-[#000000] mb-3">
            Popular <span className="text-[#89FC00] italic font-bold">Events</span>
          </h2>
          <p className="text-gray-600 text-base">
            Discover the most talked-about events everyone's attending — don't miss out!
          </p>
        </div>

        {/* Filter tabs */}
        <div className="flex items-center justify-center gap-4 mb-12">
          <button className="px-6 py-2 text-[#000000] font-medium hover:text-[#0077F7] transition-colors">
            All Events
          </button>
          <button className="px-6 py-2 text-[#000000] font-medium hover:text-[#0077F7] transition-colors">Today</button>
          <button className="px-8 py-2 bg-[#0077F7] text-white font-medium rounded-full">This week</button>
          <button className="px-6 py-2 text-[#000000] font-medium hover:text-[#0077F7] transition-colors">
            Tomorrow
          </button>
          <button className="px-6 py-2 text-[#000000] font-medium hover:text-[#0077F7] transition-colors">
            Online
          </button>
        </div>

        {/* Event cards grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          {events.map((event) => (
            <Card key={event.id} className="overflow-hidden rounded-2xl shadow-md hover:shadow-xl transition-shadow">
              <div className="relative">
                {/* Event image */}
                <div className="relative h-[240px] w-full">
                  <Image src={event.image || "/placeholder.svg"} alt={event.title} fill className="object-cover" />
                </div>

                {/* Price badge */}
                <div className="absolute top-4 right-4 bg-white px-4 py-2 rounded-full shadow-md">
                  <span className="text-[#000000] font-bold text-sm">{event.price}</span>
                </div>

                {/* Add button */}
                <button className="absolute bottom-4 right-4 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-md hover:bg-gray-100 transition-colors">
                  <Plus className="w-5 h-5 text-[#000000]" />
                </button>
              </div>

              {/* Event details */}
              <div className="p-6 bg-[#000000] text-white">
                <p className="text-sm text-gray-400 mb-2">Host By : {event.host}</p>
                <h3 className="text-xl font-bold mb-3">{event.title}</h3>
                <p className="text-sm text-gray-300 mb-4 leading-relaxed">{event.description}</p>

                {/* Event meta info */}
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-[#0077F7]" />
                    <span>{event.location}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-[#0077F7]" />
                    <span>{event.date}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-[#0077F7]" />
                    <span>{event.audience}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-[#0077F7]" />
                    <span>{event.time}</span>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* View More and About Us buttons */}
        <div className="flex items-center justify-center gap-4">
          <button className="bg-[#0077F7] hover:bg-[#0066D6] text-white px-12 py-3 rounded-lg font-medium transition-colors">
            View More
          </button>
          <button className="bg-white hover:bg-gray-100 text-[#000000] px-12 py-3 rounded-lg font-medium border-2 border-gray-200 transition-colors">
            About Us
          </button>
        </div>
      </div>
    </section>
  )
}
