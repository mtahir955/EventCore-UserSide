import Image from "next/image"
import Link from "next/link"

export function Footer() {
  return (
    <footer className="w-full bg-[#000000] text-white py-12">
      <div className="max-w-[1200px] mx-auto px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-8">
          {/* Logo and description */}
          <div className="col-span-1 md:col-span-2">
            <Image
              src="/images/logo.png"
              alt="Good Life Trainings"
              width={180}
              height={50}
              className="h-12 w-auto mb-4 brightness-0 invert"
            />
            <p className="text-gray-400 text-sm leading-relaxed mb-2">Vivamus tristique odio sit amet velit semper,</p>
            <p className="text-gray-400 text-sm leading-relaxed mb-2">eu posuere turpis interdum.</p>
            <p className="text-gray-400 text-sm leading-relaxed">Cras egestas purus</p>
          </div>

          {/* Company Info */}
          <div>
            <h3 className="text-white font-bold text-lg mb-4">Company Info</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/events" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Events
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-gray-400 hover:text-white transition-colors text-sm">
                  About
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Contact us
                </Link>
              </li>
            </ul>
          </div>

          {/* Help */}
          <div>
            <h3 className="text-white font-bold text-lg mb-4">Help</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/faqs" className="text-gray-400 hover:text-white transition-colors text-sm">
                  FAQs
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Privacy Policy
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Follow Us section */}
        <div className="mb-8">
          <h3 className="text-white font-bold text-lg mb-4">Follow Us</h3>
          <div className="flex gap-4">
            <Link href="#" className="text-gray-400 hover:text-white transition-colors text-sm">
              Facebook
            </Link>
            <Link href="#" className="text-gray-400 hover:text-white transition-colors text-sm">
              Instagram
            </Link>
            <Link href="#" className="text-gray-400 hover:text-white transition-colors text-sm">
              Twitter
            </Link>
            <Link href="#" className="text-gray-400 hover:text-white transition-colors text-sm">
              Youtube
            </Link>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-gray-800 pt-8">
          <p className="text-center text-gray-400 text-sm">©2025 Viago. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
