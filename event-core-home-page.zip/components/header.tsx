import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export function Header() {
  return (
    <>
      {/* Top banner */}
      <div className="w-full bg-[#0077F7] py-2 text-center">
        <p className="text-sm text-white font-medium">Signup today to get amazing discounts and exclusive perks!</p>
      </div>

      {/* Main header */}
      <header className="w-full bg-white border-b border-gray-200">
        <div className="max-w-[1440px] mx-auto px-8 py-4 flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center">
            <Image src="/images/logo.png" alt="Good Life Trainings" width={180} height={50} className="h-12 w-auto" />
          </Link>

          {/* Navigation */}
          <nav className="flex items-center gap-12">
            <Link href="/" className="text-[#000000] font-medium hover:text-[#0077F7] transition-colors">
              Home
            </Link>
            <Link href="/events" className="text-[#000000] font-medium hover:text-[#0077F7] transition-colors">
              Events
            </Link>
            <Link href="/about" className="text-[#000000] font-medium hover:text-[#0077F7] transition-colors">
              About
            </Link>
            <Link href="/contact" className="text-[#000000] font-medium hover:text-[#0077F7] transition-colors">
              Contact us
            </Link>
          </nav>

          {/* Login button */}
          <Button className="bg-[#0077F7] hover:bg-[#0066D6] text-white px-8 py-2 rounded-full font-medium">
            Login
          </Button>
        </div>
      </header>
    </>
  )
}
