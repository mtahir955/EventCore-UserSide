import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { SearchSection } from "@/components/search-section"
import { PopularEvents } from "@/components/popular-events"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen bg-white">
      <Header />
      <HeroSection />
      <SearchSection />
      <PopularEvents />
      <Footer />
    </main>
  )
}
